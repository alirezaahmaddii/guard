// // @ts-ignore
import {Component, EventEmitter, Input, Output} from '@angular/core';
import {bodySvg} from "./bodySvgPath";

@Component({
  selector: 'lib-body-selector',
  template: `
  <div class="w-25 h-25 mx-auto" style="background-color: black">
    <svg
      class="col-12"
      data-v-522360f0=""
      selection=""
      viewBox="0 0 68.587668 92.604164"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g>
        <path
          *ngFor="let item of path"
          (click)="addItemSelectBody(item.name)"
          id="face"
          [attr.d]="item.d"
          [class.selected-body]="checkActiveSelect(item.name)"
          fill="white"
        ></path>
      </g>
    </svg>
  </div>
  <div>
   <span class="text-white">
   </span>
  </div>
  `,
  styleUrls: ['body-selector.component.scss']
})
export class BodySelectorComponent {
  public path = bodySvg;
  @Input() bodySelect!: Array<any>;
  @Output() bodySelectChange = new EventEmitter<any>();

  public addItemSelectBody(target: string) {
    if (this.bodySelect.find(f => f.name === target)) {
      this.bodySelect.map((f)=>{
        if(f.name === target){
          let targetIndex = this.bodySelect.indexOf(f);
          this.bodySelect.splice(targetIndex, 1);
        }
      })
    } else {
      this.bodySelect.push({name: target});
    }
    this.bodySelectChange.emit(this.bodySelect);
  }

  public checkActiveSelect(tar: string) {
    return this.bodySelect.find(f => f.name === tar)
  }
}
