import { TestBed } from '@angular/core/testing';

import { BodySelectorService } from './body-selector.service';

describe('BodySelectorService', () => {
  let service: BodySelectorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BodySelectorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
