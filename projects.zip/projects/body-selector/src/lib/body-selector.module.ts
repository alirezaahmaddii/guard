import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BodySelectorComponent } from './body-selector.component';



@NgModule({
  declarations: [
    BodySelectorComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    BodySelectorComponent
  ]
})
export class BodySelectorModule { }
