/*
 * Public API Surface of body-selector
 */

export * from './lib/body-selector.service';
export * from './lib/body-selector.component';
export * from './lib/body-selector.module';
